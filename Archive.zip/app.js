//app.js

const mysql = require('mysql');
const connection = mysql.createConnection({
  host: 'kampr.co',
  user: 'kamprDB',
  password: 'Yyzh9$97',
  database: 'kampr_base'
});
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected!');
});


connection.query('SELECT * FROM camp_details', (err,rows) => {
  if(err) throw err;

  console.log('Data received from Db:\n');
  console.log(rows);
});

connection.end();